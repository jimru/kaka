$(document).ready(function () {
    $("#loginform").validate({
        rules: {
  			"username":{
  				required: true,
  				email: true
  			},	
  			"password":{
  				required: true,
  				checkPassowrd: true
  			}
        },
        messages: {	
			"username":{
  				email: "Please enter a valid email Id.",
  				required: "Email is a required field."
			},
  			"password":{
  				required: "Passowrd is a required field."
  			}
       },
        submitHandler: function (form) { 
        	console.log("***Login Validation Completed.!");
        	form.submit();
    	}
    });

});