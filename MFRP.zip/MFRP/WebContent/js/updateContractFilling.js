function fetchValue() {
	
	mydropdown = document.getElementById("name_of_contract"),
	$.ajax({
		type: 'GET',
		contentType: "application/json; charset=utf-8",
		url: "/MFRP/ContractDisplay?contract="+mydropdown.value,
		dataType: "text",
		success: function(resultData) { 
			var details=resultData;
			var result=details.split("/");
			$('#contract_name').val(result[0]);
			$('#start_date').val(result[1]);
			$('#no_of_years').val(result[2]);
		},
		error: function(){}
	});		
 }



