$(document).ready(function () {
    $("#formUpdate").validate({
    	   rules: {
           	"lock":{
                   required: true
           	},
                   	
            "start_date": {
    			startDate: true,
    			ageLimit:true
    			
  			},
  			"contract_name" : {
  				alphanumeric: true
  			},
  			"no_of_years": {
  				number: true
  			}
        },
        messages: {		
        	"lock": {
            required : "check the checbox"
        	},
        	"contract_name" : {
                required: "Contract Name is required."     
            },
            "start_date": {
            	required: "Start Date is required."     
  			},
  			"no_of_years": {
  				required: "No of Years is required." ,    
  				number: "Please enter a valid number."
  			}
       },
        submitHandler: function (form) { 
        	console.log("Submitted!");
        	form.submit();
    	}
    });
    $.validator.addMethod( "startDate", function (value, element) {
        if($('#start_date').val() === 2017 || value>2016 ){
        	return true;
        }
        else
        	return false;
      }, "Please enter Current Year or above."
    );
    $.validator.addMethod( "ageLimit", function (value, element) {
        if(value>2016)
     	   return true;
       }, "Please enter Current Year or above"
     );
    $.validator.addMethod("alphanumeric", function(value, element) {
        return  value.match(/^[a-zA-Z0-9]+$/);
    }, "Please enter Alphanumeric contract Name"); 
});