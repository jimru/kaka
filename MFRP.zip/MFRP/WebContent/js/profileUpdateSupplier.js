$(document).ready(function () {
    $("#updateSupplierValidator").validate({
        rules: {
        	"lock":{
                required: true
                	
      
             },
            "fname": {
            	 required: true,
                 maxlength: 20,
                 lettersonly: true
  			},
  			"lname": {
  				required: true,
                maxlength: 20,
                lettersonly: true
 			},
 			"age":{
 				required: true,
 				ageLimit : true
 				
 			},
 			"contactno": {
 				required: true,
  				number: true
  			},
  			"email":{
  				required: true,
  				email: true
  			},
  			"address":{
  				required: true
  			},
  			"password":{
  				required: true,
  				checkPassowrd: true
  			},
  			
        },
        messages: {
        	 "lock": {
                 required : "check the checbox"
               },
        	"fname": {
            	 maxlength: "Maximum character should be of 20 character.",
            	 required: "First Name is a required field.",
            },
        	"lname": {
		       	 maxlength: "Maximum character should be of 20 character.",
		       	 required: "Last Name is a required field.",
		    },
			"contactno":{
				number: "Please enter a valid number.",
				required: "Contact No. is a required field."
			},
			"email":{
  				email: "Please enter a valid email Id.",
  				required: "Email is a required field."
  			},
  			"age":{
  				required: "Age is a required field."
  			},
  			"address":{
  				required: "Address is a required field."
  			},
  			"password":{
  				required: "Passowrd is a required field."
  			}
       },
        submitHandler: function (form) { 
        	console.log("****Registration Validation Completed.!");
        	form.submit();
    	}
    });
    $.validator.addMethod( "ageLimit", function (value, element) {
        if($('#type').val() === 'admin' && value>24){
        	return true;
        }
        else if($('#type').val() === 'supplier' && value>21){
        	return true;
        }
        else
        	return false;
      }, "Invalid age limit."
    );
    $.validator.addMethod( "checkPassowrd", function (value, element) {
    	return value.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$/);
      }, "Invalid Password."
    );
    $.validator.addMethod("lettersonly", function(value, element) {
	  return  value.match(/^[a-z]+$/i);
	}, "Only Alphabets are allowed.");
});