$(document).ready(function () {
    $("#lockform").validate({
        rules: {
        	"lock":{
                required: true
                	
      
             },
            "amenity": {
            	 required: true,
                
  			},
  			"amenitycategory": {
  				required: true,
               
 			},
 			"features":{
 				required: true,
 			},
 			"agree":{
 				required: true,
 			}
        },
        messages: {
        	 "lock": {
                 required : "Lock the Contract"
               },
        	"amenity": {
            	 required: "Amenity is a required field.",
            },
        	"amenitycategory": {
		       	 required: "AmenityCategory is a required field.",
		    },
			"features":{
				required: "Features is a required field."
		
		
  			}
        },
 
    submitHandler: function (form) { 
    	console.log("***Login Validation Completed.!");
    	form.submit();
	}
});

});