function alerts() {
	alert("Registerd Successfully!! Log in for the First Time");
}
function setZip() {
	
	mydropdown = document.getElementById("city"),
	$.ajax({
		type: 'GET',
		contentType: "application/json; charset=utf-8",
		url: "/MFRP/emailservlet?city="+mydropdown.value,
		dataType: "text",
		success: function(resultData) { 
			$('#zipcode').val(resultData);
		},
		error: function(){}
	});		
 }


function onLoad(){
	if(loginError){
		document.getElementById("lock_div").style.visibility = "visible";
	}else{
		document.getElementById("lock_div").style.visibility = "hidden";
	}
	
}
function removeErrorMsg(){
	loginError= false;
	onLoad();
	
}


