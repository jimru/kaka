package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.model.LoginBO;
import com.cts.vo.Login;
import com.sun.xml.internal.ws.client.SenderException;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if (request.getParameter("login") != null) {
			Login login = new Login();
			login.setUserName(request.getParameter("username"));
			login.setPassword(request.getParameter("password"));
			LoginBO lbo = new LoginBO();
			if (lbo.validateLogin(login)) {
				String type = lbo.getType(login);
				if (type.equals("admin")) {
					request.setAttribute("login_message", "Login Successfull Admin!!!");
				    request.getRequestDispatcher("login.jsp").forward(request,response);
				} else {
					request.setAttribute("login_message", "Login Successfull Supplier!!!");
				    request.getRequestDispatcher("login.jsp").forward(request,response);
				}
					
				}
			else
			{
				request.setAttribute("login_message", "Login Failed!!!");
			    request.getRequestDispatcher("login.jsp").forward(request,response);
			}
		}
	}
}
	

