package com.cts.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.model.CreateContractBO;
import com.cts.vo.Contract;
import com.sun.xml.internal.bind.v2.runtime.reflect.opt.Const;

/**
 * Servlet implementation class Create_Contract
 */
public class Create_Contract_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Create_Contract_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		Contract contract=new Contract();
		contract.setContarct_name(request.getParameter("contract_name"));
		contract.setContract_id("MA");
		contract.setType_of_contract(request.getParameter("type_of_contract"));	
		contract.setStart_date(request.getParameter("start_date"));	
		contract.setNo_of_years(Integer.parseInt(request.getParameter("no_of_years")));
		contract.setStatus("pending");
		HttpSession s=request.getSession(true);
		String user=s.getAttribute("username").toString();
		contract.setUsername(user);		
		CreateContractBO cbo=new CreateContractBO();
		if(cbo.createContract(contract))
		{	
		request.setAttribute("contract_message", "Contract Created!!!");
	    request.getRequestDispatcher("Create_Contract.jsp").forward(request,response);
		}
		else
		{
		request.setAttribute("contract_message", "false");
	    request.getRequestDispatcher("Create_Contract.jsp").forward(request,response);
		}

 		
	
	}

}
