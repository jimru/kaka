package com.cts.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.model.RegisterBO;
import com.cts.vo.Register;

/**
 * Servlet implementation class updateServletSupplier
 */
public class updateServletSupplier extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateServletSupplier() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Register update=new Register();
		update.setFirst_name(request.getParameter("first_name"));
		update.setPassword(request.getParameter("password"));
		update.setFirst_name(request.getParameter("fname"));
		update.setLast_name(request.getParameter("lname"));
		update.setAge(Integer.parseInt(request.getParameter("age")));
		update.setGender(request.getParameter("gender"));
		update.setContact_no(request.getParameter("contactno"));
		update.setAddress(request.getParameter("address"));
		update.setZip(request.getParameter("zipcode"));
		update.setCity(request.getParameter("city"));
		update.setType(request.getParameter("type"));
		HttpSession s=request.getSession(true);
		String email=s.getAttribute("username").toString();
		update.setEmail(email);
		RegisterBO updatebo=new RegisterBO();
		if(updatebo.updateAdmin(update))
		{
			request.setAttribute("profile_update_message", "Profile Updated!!!");
		    request.getRequestDispatcher("Update_Supplier_Profile.jsp").forward(request,response);		}
		
	}

}