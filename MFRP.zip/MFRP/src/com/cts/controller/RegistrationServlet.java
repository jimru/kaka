package com.cts.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.Response;

import org.apache.catalina.connector.Request;

import com.cts.model.RegisterBO;
import com.cts.vo.Register;

/**
 * Servlet implementation class RegestrationServlet
 */
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Register r=new Register();
		Register r1=new Register();
		r.setPassword(request.getParameter("password"));
		r.setFirst_name(request.getParameter("fname"));
		r.setLast_name(request.getParameter("lname"));
		r.setAge(Integer.parseInt(request.getParameter("age")));
		r.setGender(request.getParameter("gender"));
		r.setContact_no(request.getParameter("contactno"));
		r.setEmail(request.getParameter("email"));
		r.setAddress(request.getParameter("address"));
		r.setZip(request.getParameter("zipcode"));
		r.setCity(request.getParameter("city"));
		r.setType(request.getParameter("type"));
		RegisterBO rbo=new RegisterBO();
		if(rbo.registerUser(r))
		{
			r1=rbo.getUserId(request.getParameter("email"));		
			request.setAttribute("registration_message", "Successfully Registered!!!Your UserName is "+r1.getEmail());
		    request.getRequestDispatcher("Registration.jsp").forward(request,response);
		   
		}
		else
		{
			request.setAttribute("registration_message1", "false");
		    request.getRequestDispatcher("Registration.jsp").forward(request,response);
		}
		
		
		
	}

}
