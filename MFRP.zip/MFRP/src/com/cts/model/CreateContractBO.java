package com.cts.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.dao.CreateContractDAO;
import com.cts.vo.Contract;
import com.cts.vo.Login;
import com.cts.vo.Register;


public class CreateContractBO {
	
	boolean result=false;
	boolean result1=false;
	boolean result2=false;
	public boolean createContract(Contract contract)
	{
		
		result=CreateContractDAO.createContract(contract);
				return result;
	}
	
	public boolean updateContract(Contract contract,String username,String old_contract_name)
	{
		result1=CreateContractDAO.updateContract(contract,username,old_contract_name);
		return result1;
	}
	
	public List<Contract> displayContract(String username)
	{
		List<Contract> display_contract=new ArrayList<Contract>();
		display_contract=CreateContractDAO.displayContract(username);
		return display_contract;
	}
	
	public List<Contract> display_Contract_by_type(String username,String type)
	{
		List<Contract> display_Contract_by_type=new ArrayList<Contract>();
		display_Contract_by_type=CreateContractDAO.display_Contract_by_type(username,type);
		return display_Contract_by_type;
	}
	public List<Contract> displaySupplierContract()
	{
		List<Contract> display_supplier_contract=new ArrayList<Contract>();
		display_supplier_contract=CreateContractDAO.displaySupplierContract();
		return display_supplier_contract;
	}
	public Register get_UserName(Login User_id)
	{
		Register register=CreateContractDAO.get_UserName(User_id.getLogid());
		return register;
	}
	public Contract get_UserId(int Userid,String contractname)
	{
		Contract contract=new Contract();
		contract=CreateContractDAO.get_UserId(Userid, contractname);
		return contract;
		
	}
	public Contract get_contract_id(String contract_name)
	{
		Contract contract=new Contract();
		contract=CreateContractDAO.get_contract_id(contract_name);
		return contract;
		
	}
	public Contract get_contract_details(String contract_id)
	{
		Contract contract=new Contract();
		contract=CreateContractDAO.get_contract_details(contract_id);
		return contract;
		
	}

	public List<Contract> displaySupplier_All_Contract()
	{
		List<Contract> display_supplier_contract=new ArrayList<Contract>();
		display_supplier_contract=CreateContractDAO.displaySupplier_All_Contract();
		return display_supplier_contract;
	}
}
