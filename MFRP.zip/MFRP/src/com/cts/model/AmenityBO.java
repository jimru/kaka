package com.cts.model;

import java.util.ArrayList;
import java.util.List;

import com.cts.dao.AmenityDAO;
import com.cts.dao.LoginDAO;
import com.cts.vo.Amenity;

public class AmenityBO {
	
	boolean result=false;
	public boolean Insert_Amenity(Amenity amenity)
	{
		result=AmenityDAO.Insert_Amenity(amenity);
		return result;
		
	}
	public boolean Update_Contract(Amenity amenity)
	{
		result=AmenityDAO.Update_Contract_locking(amenity);
		return result;
		
	}
	public List<Amenity> Display(String username)
	{
		List<Amenity> list=new ArrayList<Amenity>();
		list=AmenityDAO.Display(username);
		return list;
		
	}
	public Amenity Display_Contract_id(String amenity_name)
	{
		Amenity amenity=new Amenity();
		amenity=AmenityDAO.Display_Contract_id(amenity_name);
		return amenity;
	}
	public boolean Update_Amenity_status(Amenity amenity)
	{
		result=AmenityDAO.Update_Amenity_status(amenity);
		return result;
		
	}
	public List<Amenity> Display_AMINITY_SUPPLIERS(String username)
	{
		List<Amenity> list=new ArrayList<Amenity>();
		list=AmenityDAO.Display_AMINITY_SUPPLIERS(username);
		return list;
		
	}
	
}
