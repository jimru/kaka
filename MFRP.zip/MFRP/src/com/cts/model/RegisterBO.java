package com.cts.model;

import java.util.ArrayList;
import java.util.List;

import com.cts.dao.RegistrationDAO;
import com.cts.vo.Location;
import com.cts.vo.Register;


public class RegisterBO {

	public boolean registerUser(Register register)
	{
		boolean result=false;
		 result=RegistrationDAO.registerUser(register);
		 return result;
		
	}
	boolean result1=false;
	public boolean updateAdmin(Register update)
	{
		result1=RegistrationDAO.updateAdmin(update);
		return result1;
		
		
		
	}
	
	public String getZipcode(String city)
	{
		String location="";
		location=RegistrationDAO.getZipcode(city);
		return location;
	}
	
	public List<Location> getCity()
	{
		List<Location> list=new ArrayList<Location>();
		list=RegistrationDAO.getCity();
		return list;
	}
	public Register getUserId(String name)
	{
		Register reg=new Register();
		reg=RegistrationDAO.getUserId(name);
		return reg;
	}
}
