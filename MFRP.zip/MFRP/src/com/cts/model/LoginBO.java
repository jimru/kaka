package com.cts.model;

import com.cts.dao.LoginDAO;
import com.cts.vo.Login;

public class LoginBO {
	boolean result=false;
	String type=null;
	public boolean validateLogin(Login login)
	{
		
		result=LoginDAO.validateLogin(login);
		
		return result;
	}
	public String getType(Login login)
	{
		
		type=LoginDAO.getType(login);
		
		return type;
	}
	public Login getLogin(int user_id)
	{
		Login login=new Login();
		login=LoginDAO.getLogin(user_id);
		return login;
	}
	public Login getLogin_by_username(String user_name)
	{
		Login login=new Login();
		login=LoginDAO.getLogin_by_username(user_name);
		return login;
	}
}
