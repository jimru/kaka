package com.cts.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.cts.vo.Login;

public class DBConnect {
Connection con=null;
public Connection getConnect()
{
	if(con==null)
	{
		ResourceBundle rs=ResourceBundle.getBundle("DBProperties");
		try {
			Class.forName(rs.getString("driver"));
			try {
				con=DriverManager.getConnection(rs.getString("url"),rs.getString("username"),rs.getString("password"));
			} catch (SQLException e) {
				System.err.println(e);
			}
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}
	}
	return con;
}
}
