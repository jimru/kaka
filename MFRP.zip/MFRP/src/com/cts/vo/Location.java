package com.cts.vo;

public class Location {

	private String City;
	private String Zip_code;
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getZip_code() {
		return Zip_code;
	}
	public void setZip_code(String zip_code) {
		Zip_code = zip_code;
	}
	public Location(String city, String zip_code) {
		super();
		City = city;
		Zip_code = zip_code;
	}
	public Location()
	{
		
	}
}
