package com.cts.vo;

public class Register {
	private String password;
	private String first_name;
	private String last_name;
	private int age;
	private String gender;
	private String contact_no;
	private String email;
	private String address;
	private String zip;
	private String city;
	private String type;
	private int Reg_id;
	public int getReg_id() {
		return Reg_id;
	}
	public void setReg_id(int reg_id) {
		Reg_id = reg_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Register(int Reg_id, String first_name, String last_name,
			int age, String gender, String contact_no, String email,
			String address, String zip, String city, String type) {
		super();
		this.Reg_id=Reg_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.age = age;
		this.gender = gender;
		this.contact_no = contact_no;
		this.email = email;
		this.address = address;
		this.zip = zip;
		this.city = city;
		this.type = type;
	}
	public Register()
	{
		
	}
	
}
