package com.cts.vo;

public class Amenity {

	private String name;
	private String category;
	private String features;
	private Contract contract_id;
	private int id;
	private Login supplier_id;
	private int admin_id;
	private String status;
	private String reason;

	public String getName() {
		return name;
	}

	public Amenity(String name, String category, String features,
			Contract contract_id, int id, Login supplier_id, int admin_id,
			String status, String reason) {
		super();
		this.name = name;
		this.category = category;
		this.features = features;
		this.contract_id = contract_id;
		this.id = id;
		this.supplier_id = supplier_id;
		this.admin_id = admin_id;
		this.status = status;
		this.reason = reason;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public Contract getContract_id() {
		return contract_id;
	}

	public void setContract_id(Contract contract_id) {
		this.contract_id = contract_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Login getSupplier_id() {
		return supplier_id;
	}

	public void setSupplier_id(Login supplier_id) {
		this.supplier_id = supplier_id;
	}

	public int getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	public Amenity()
	{
	
	}
	

	
}
