package com.cts.vo;

import java.util.Date;

public class Contract {
	private Login userid;
	private String contarct_name;
	private String type_of_contract;
	private String start_date;
	private int no_of_years;
	private String status;
	private String contract_id;
	private String username;
	
	
	


	public Login getUserid() {
		return userid;
	}


	public void setUserid(Login userid) {
		this.userid = userid;
	}


	public String getContarct_name() {
		return contarct_name;
	}


	public void setContarct_name(String contarct_name) {
		this.contarct_name = contarct_name;
	}


	public String getType_of_contract() {
		return type_of_contract;
	}


	public void setType_of_contract(String type_of_contract) {
		this.type_of_contract = type_of_contract;
	}


	public String getStart_date() {
		return start_date;
	}


	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}


	public int getNo_of_years() {
		return no_of_years;
	}


	public void setNo_of_years(int no_of_years) {
		this.no_of_years = no_of_years;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getContract_id() {
		return contract_id;
	}


	public void setContract_id(String contract_id) {
		this.contract_id = contract_id;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public Contract(Login userid, String contarct_name, String type_of_contract,
			String start_date, int no_of_years, String status,
			String contract_id, String username) {
		super();
		this.userid = userid;
		this.contarct_name = contarct_name;
		this.type_of_contract = type_of_contract;
		this.start_date = start_date;
		this.no_of_years = no_of_years;
		this.status = status;
		this.contract_id = contract_id;
		this.username = username;
	}
	public Contract(String contarct_name, String type_of_contract,
			String start_date, int no_of_years,String status) {
		super();
		this.contarct_name = contarct_name;
		this.type_of_contract = type_of_contract;
		this.start_date = start_date;
		this.no_of_years = no_of_years;
		this.status = status;
	}
	public Contract(String contarct_name, String type_of_contract,
			String start_date, int no_of_years) {
		super();
		this.contarct_name = contarct_name;
		this.type_of_contract = type_of_contract;
		this.start_date = start_date;
		this.no_of_years = no_of_years;
		
	}

	public Contract(Login userid,String contarct_name, String type_of_contract,
			String start_date, int no_of_years,String status) {
		super();
		this.userid = userid;
		this.contarct_name = contarct_name;
		this.type_of_contract = type_of_contract;
		this.start_date = start_date;
		this.no_of_years = no_of_years;
		this.status = status;
	}
	public Contract(Login userid, String contarct_name, String type_of_contract,
			String start_date, int no_of_years, String status,
			String contract_id) {
		super();
		this.userid = userid;
		this.contarct_name = contarct_name;
		this.type_of_contract = type_of_contract;
		this.start_date = start_date;
		this.no_of_years = no_of_years;
		this.status = status;
		this.contract_id = contract_id;
		this.username = username;
	}
	public Contract()
	{
		
	}



	

}
