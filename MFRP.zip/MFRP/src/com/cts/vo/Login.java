package com.cts.vo;

public class Login {
	private Register logid;
	
	private String UserName;
	private String password;
	public Register getLogid() {
		return logid;
	}
	public void setLogid(Register logid) {
		this.logid = logid;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Login(Register logid,String userName, String password) {
		super();
		this.logid=logid;
		this.UserName = userName;
		this.password = password;
	}
	public Login()
	{
	}
	

	

}
