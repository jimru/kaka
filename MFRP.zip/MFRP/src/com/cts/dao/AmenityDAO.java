package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.catalina.connector.Request;

import com.cts.model.CreateContractBO;
import com.cts.model.LoginBO;
import com.cts.util.DBConnect;
import com.cts.vo.Amenity;
import com.cts.vo.Contract;
import com.cts.vo.Register;

public class AmenityDAO {

	public static boolean Insert_Amenity(Amenity amenity)
	{
		Register register=new Register();
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("INSERT_AMENITY"));
			preparestatement.setString(1, amenity.getName());
			preparestatement.setString(2, amenity.getCategory());
			preparestatement.setString(3, amenity.getFeatures());
			preparestatement.setString(4, amenity.getContract_id().getContract_id());
			preparestatement.setInt(5, amenity.getSupplier_id().getLogid().getReg_id());
			preparestatement.setInt(6, amenity.getAdmin_id());
			preparestatement.setString(7, amenity.getReason());
			preparestatement.setString(8, amenity.getStatus());
			preparestatement.executeUpdate();
			result=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static boolean Update_Contract_locking(Amenity amenity)
	{
		Register register=new Register();
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("UPDATE_LOCK"));
			preparestatement.setString(1, "Pending Paper Contract Receipt");
			preparestatement.setString(2,  amenity.getContract_id().getContract_id());
			preparestatement.executeUpdate();
			result=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static List<Amenity> Display(String username)
	{
		List<Amenity> list_ame=new ArrayList<Amenity>();
		Register register=new Register();
		LoginBO loginbo=new LoginBO();
		CreateContractBO contractbo=new CreateContractBO();
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("GET_AMINITY"));
			preparestatement.setInt(1, loginbo.getLogin_by_username(username).getLogid().getReg_id());
			ResultSet resultset=preparestatement.executeQuery();
			while(resultset.next())
			{
				Amenity amenity=new Amenity(resultset.getString("name"),resultset.getString("category"),resultset.getString("features"),contractbo.get_contract_details(resultset.getString("contract_id")),resultset.getInt("id"),loginbo.getLogin(resultset.getInt("supplier_id")),resultset.getInt("admin_id"),resultset.getString("status"),resultset.getString("Reason"));
				list_ame.add(amenity);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list_ame;
	}
	public static boolean Update_Amenity_status(Amenity amenity)
	{
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("UPDATE_AMINITY_STATUS"));
			preparestatement.setString(1, amenity.getReason());
			preparestatement.setString(2,  amenity.getStatus());
			preparestatement.setString(3,  amenity.getName());
			preparestatement.executeUpdate();
			PreparedStatement preparestatement1=con.prepareStatement(resourcebundle.getString("UPDATE_CONTRACT_STATUS"));
			preparestatement1.setString(1, amenity.getStatus());
			preparestatement1.setString(2,amenity.getContract_id().getContract_id());
			preparestatement1.executeUpdate();
			result=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	public static Amenity Display_Contract_id(String amenity_name)
	{
		Amenity amenity=new Amenity();
		Register register=new Register();
		LoginBO loginbo=new LoginBO();
		CreateContractBO contractbo=new CreateContractBO();
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("GET_CONTRACT_NAME"));
			preparestatement.setString(1, amenity_name);
			ResultSet resultset=preparestatement.executeQuery();
			if(resultset.next())
			{
				 amenity=new Amenity(resultset.getString("name"),resultset.getString("category"),resultset.getString("features"),contractbo.get_contract_details(resultset.getString("contract_id")),resultset.getInt("id"),loginbo.getLogin(resultset.getInt("supplier_id")),resultset.getInt("admin_id"),resultset.getString("status"),resultset.getString("Reason"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return amenity;
	}
	
	public static List<Amenity> Display_AMINITY_SUPPLIERS(String username)
	{
		List<Amenity> list_ame=new ArrayList<Amenity>();
		Register register=new Register();
		LoginBO loginbo=new LoginBO();
		CreateContractBO contractbo=new CreateContractBO();
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("GET_AMINITY_SUPPLIER_ID"));
			preparestatement.setInt(1, loginbo.getLogin_by_username(username).getLogid().getReg_id());
			ResultSet resultset=preparestatement.executeQuery();
			while(resultset.next())
			{
				Amenity amenity=new Amenity(resultset.getString("name"),resultset.getString("category"),resultset.getString("features"),contractbo.get_contract_details(resultset.getString("contract_id")),resultset.getInt("id"),loginbo.getLogin(resultset.getInt("supplier_id")),resultset.getInt("admin_id"),resultset.getString("status"),resultset.getString("Reason"));
				list_ame.add(amenity);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list_ame;
	}

	
	
}
