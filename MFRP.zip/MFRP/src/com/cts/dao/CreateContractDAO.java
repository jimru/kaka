package com.cts.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.HttpSession;

import org.apache.catalina.connector.Request;

import com.cts.util.DBConnect;
import com.cts.vo.Contract;
import com.cts.vo.Login;
import com.cts.vo.Register;

;

public class CreateContractDAO {
	
	
	public static boolean createContract(Contract contract)
	{
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		
	ResourceBundle rs=ResourceBundle.getBundle("QueryConstant");
		boolean result=false;
		
	try {
		PreparedStatement preparestatement1=con.prepareStatement(rs.getString("FETCH_REG_ID"));
		preparestatement1.setString(1, contract.getUsername());
		ResultSet resultset=preparestatement1.executeQuery();
		if(resultset.next())
		{
			
		
			if(contract.getStart_date().matches("[0-9]{4}"));
			{
			
		
			Integer in=CreateContractDAO.getUserId(contract.getUsername()).getLogid().getReg_id();
			String contract_id=contract.getContract_id();
			StringBuilder last_sequence_contract=new StringBuilder(in.toString());
			
			
			contract_id=contract_id+"_"+contract.getUsername().substring(0,3).toUpperCase();
	 		contract_id=contract_id+"_"+contract.getContarct_name().substring(0,3).toUpperCase();
	 		contract_id=contract_id+"_"+contract.getStart_date();
			contract_id=contract_id+last_sequence_contract.toString();
			int current_year=Calendar.getInstance().get(Calendar.YEAR);
			int year=Integer.parseInt(contract.getStart_date());
	 		if(year<Calendar.getInstance().get(Calendar.YEAR))
	 		{
	 			contract.setType_of_contract("Last Period Contract");
	 		}
	 		else if(year==Calendar.getInstance().get(Calendar.YEAR))
	 		{
	 			contract.setType_of_contract("Current Period Contract");
	 		}
	 		else if(year>Calendar.getInstance().get(Calendar.YEAR))
	 		{
	 			contract.setType_of_contract("Next Period Contract");
	 		}
	 		PreparedStatement preparestatement2=con.prepareStatement(rs.getString("CREATE_CONTRACT"));
			
			preparestatement2.setString(1, contract_id);
			preparestatement2.setInt(2, CreateContractDAO.getUserId(contract.getUsername()).getLogid().getReg_id());
			preparestatement2.setString(3, contract.getContarct_name());
			preparestatement2.setString(4, contract.getType_of_contract());
		//	preparestatement2.setDate(5, java.sql.Date.valueOf(start_date.toString()));
			preparestatement2.setString(5,contract.getStart_date());
			preparestatement2.setInt(6,contract.getNo_of_years());
			preparestatement2.setString(7, contract.getStatus());
			preparestatement2.executeUpdate();
			result=true;
			}
		
		
		}
	}
	 catch (SQLException e) {
		// TODO Auto-generated catch block
	System.err.println(e);
	 }
	
		return result;
	
	}
	
	public static Login getUserId(String name)
	{
		Login login=null;
		DBConnect dconnect=new DBConnect();
		boolean result=false;
		Connection con=dconnect.getConnect();
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		try
		{
		PreparedStatement preparestatement=con.prepareStatement(rb.getString("FETCH_LOGIN_DETAILS"));
		preparestatement.setString(1, name);
		ResultSet resultset=preparestatement.executeQuery();
			if(resultset.next())
			{
				 login=new Login(RegistrationDAO.getUserId(name),resultset.getString("user_name"),resultset.getString("password"));
			} 
		
		}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				System.err.println(e);
	}
		return login;
		
	}
	
	public static boolean updateContract(Contract contract,String username,String old_contract_name) {
		int year=Integer.parseInt(contract.getStart_date());
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		boolean result=false;
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			int current_year=Calendar.getInstance().get(Calendar.YEAR);
			
			if(year==Calendar.getInstance().get(Calendar.YEAR))
	 		{
	 			contract.setType_of_contract("Current Period Contract");
	 		}
	 		else if(year>Calendar.getInstance().get(Calendar.YEAR))
	 		{
	 			contract.setType_of_contract("Next Period Contract");
	 		}
			PreparedStatement preparestatement1=con.prepareStatement(resourcebundle.getString("GET_CONTRACT_ID"));
			preparestatement1.setInt(1,RegistrationDAO.getUserId(username).getReg_id());
			preparestatement1.setString(2,old_contract_name);
			ResultSet resultset1=preparestatement1.executeQuery();
			if(resultset1.next())
			{
				PreparedStatement preparedstatement2=con.prepareStatement(resourcebundle.getString("UPDATE_CONTRACT"));
				preparedstatement2.setString(1, contract.getContarct_name());
				preparedstatement2.setString(2, contract.getType_of_contract());
				preparedstatement2.setString(3, contract.getStart_date());
				preparedstatement2.setInt(4, contract.getNo_of_years());
				preparedstatement2.setString(5, resultset1.getString("Contract_id"));
				preparedstatement2.executeUpdate();
				
				result=true;
			}
			
			
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	} 
	
	
	
	public static List<Contract> displayContract(String username)
	{
		List<Contract> contract_list=new ArrayList<Contract>();
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		
	ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
	try {
		PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("DISPLAY_CONTRACT"));
		preparestatement.setInt(1, CreateContractDAO.getUserId(username).getLogid().getReg_id());
		ResultSet resultset=preparestatement.executeQuery();
		
		while(resultset.next())
		{
			Contract display_contract=new Contract(resultset.getString("Contract_name"),resultset.getString("Type_of_contract"),resultset.getString("Start_date"),resultset.getInt("No_of_years_contract"));
			contract_list.add(display_contract);
		}
		
		
		
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return contract_list;
	
	}
	
	public static List<Contract> display_Contract_by_type(String username,String type)
	{
		List<Contract> display_Contract_by_type=new ArrayList<Contract>();
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		
	ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
	try {
		PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("DISPLAY_CONTRACT_BY_TYPE"));
		preparestatement.setInt(1, CreateContractDAO.getUserId(username).getLogid().getReg_id());
		preparestatement.setString(2, type);
		ResultSet resultset=preparestatement.executeQuery();
		
		while(resultset.next())
		{
			Contract display_contract=new Contract(resultset.getString("Contract_name"),resultset.getString("Type_of_contract"),resultset.getString("Start_date"),resultset.getInt("No_of_years_contract"),resultset.getString("Contract_status"));
			display_Contract_by_type.add(display_contract);
		}
		
		
		
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return display_Contract_by_type;
	
		
	}
	

	
	public static List<Contract> displaySupplierContract()
	{
		List<Contract> contract_list_supplier=new ArrayList<Contract>();
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement_contract=con.prepareStatement(resourcebundle.getString("DISPLAY_SUPPLIER_CONTRACT"));
			ResultSet resultset_supplier=preparestatement_contract.executeQuery();
			while(resultset_supplier.next())
			{
				Contract contract_supplier= new Contract(LoginDAO.getLogin(resultset_supplier.getInt("User_id")),resultset_supplier.getString("Contract_name"),resultset_supplier.getString("Type_of_contract"),resultset_supplier.getString("Start_date"),resultset_supplier.getInt("No_of_years_contract"),resultset_supplier.getString("Contract_status"));
				contract_list_supplier.add(contract_supplier);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
		}
		return contract_list_supplier;
	
	}
	
	public static Register get_UserName(Register User_id)
	{
		Register register=new Register();
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement_contract=con.prepareStatement(resourcebundle.getString("FETCH_USER_NAME"));
			preparestatement_contract.setInt(1, User_id.getReg_id());
			ResultSet resultset_User_id=preparestatement_contract.executeQuery();
			while(resultset_User_id.next())
			{
				register=new Register(resultset_User_id.getInt("Reg_id"),resultset_User_id.getString("First_name"),resultset_User_id.getString("Last_name"),resultset_User_id.getInt("Age"),resultset_User_id.getString("Gender"),resultset_User_id.getString("Contact_number"),resultset_User_id.getString("Email"),resultset_User_id.getString("Address"),resultset_User_id.getString("Zip_code"),resultset_User_id.getString("City"),resultset_User_id.getString("Type"));
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return register;
	}
	
	
	public static Contract get_UserId(int Userid,String contractname)
	{
		Contract contract=new Contract();
		boolean result=false;
		
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("GET_CONTRACT_ID"));
			preparestatement.setInt(1, Userid);
			preparestatement.setString(2, contractname);
			ResultSet resultset=preparestatement.executeQuery();
			if(resultset.next())
			{
				 contract= new Contract(LoginDAO.getLogin(resultset.getInt("User_id")),resultset.getString("Contract_name"),resultset.getString("Type_of_contract"),resultset.getString("Start_date"),resultset.getInt("No_of_years_contract"),resultset.getString("Contract_status"),resultset.getString("Contract_id"));
				 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return contract;
	}
	
	
	public static Contract get_contract_id(String contract_name)
	{
		Contract contract=new Contract();
		boolean result=false;
		
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("GET_CONTRACT_DETAILS"));
			preparestatement.setString(1, contract_name);
			ResultSet resultset=preparestatement.executeQuery();
			if(resultset.next())
			{
				 contract= new Contract(LoginDAO.getLogin(resultset.getInt("User_id")),resultset.getString("Contract_name"),resultset.getString("Type_of_contract"),resultset.getString("Start_date"),resultset.getInt("No_of_years_contract"),resultset.getString("Contract_status"),resultset.getString("Contract_id"));
				 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return contract;
	}
	
	public static Contract get_contract_details(String contract_id)
	{
		Contract contract=new Contract();
		boolean result=false;
		
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement=con.prepareStatement(resourcebundle.getString("GET_AMINITY_CONTRACT"));
			preparestatement.setString(1, contract_id);
			ResultSet resultset=preparestatement.executeQuery();
			if(resultset.next())
			{
				 contract= new Contract(LoginDAO.getLogin(resultset.getInt("User_id")),resultset.getString("Contract_name"),resultset.getString("Type_of_contract"),resultset.getString("Start_date"),resultset.getInt("No_of_years_contract"),resultset.getString("Contract_status"),resultset.getString("Contract_id"));
				 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return contract;
	}

	
	public static List<Contract> displaySupplier_All_Contract()
	{
		List<Contract> contract_list_supplier=new ArrayList<Contract>();
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		ResourceBundle resourcebundle=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement_contract=con.prepareStatement(resourcebundle.getString("DISPLAY_SUPPLIER_ALL_CONTRACT"));
			ResultSet resultset_supplier=preparestatement_contract.executeQuery();
			while(resultset_supplier.next())
			{
				Contract contract_supplier= new Contract(LoginDAO.getLogin(resultset_supplier.getInt("User_id")),resultset_supplier.getString("Contract_name"),resultset_supplier.getString("Type_of_contract"),resultset_supplier.getString("Start_date"),resultset_supplier.getInt("No_of_years_contract"),resultset_supplier.getString("Contract_status"));
				contract_list_supplier.add(contract_supplier);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
		}
		return contract_list_supplier;
	
	}

	

}
