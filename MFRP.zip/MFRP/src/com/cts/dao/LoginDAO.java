package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.cts.util.DBConnect;
import com.cts.vo.Login;
import com.cts.vo.Register;

public class LoginDAO {
	public static boolean validateLogin(Login login)
	{
		boolean result=false;
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		PreparedStatement ps;
		try {
			ps=con.prepareStatement(rb.getString("CHECK_LOGIN"));
			ps.setString(1, login.getUserName());
			ps.setString(2, login.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				result=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	public static String getType(Login login)
	{
		String type=null;
		boolean result=false;
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		PreparedStatement ps;
		PreparedStatement ps1;
		try {
			ps=con.prepareStatement(rb.getString("FETCH_REG_ID"));
			ps.setString(1, login.getUserName());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				ps1=con.prepareStatement(rb.getString("FETCH_USER_TYPE"));
				ps1.setInt(1, rs.getInt("Reg_id"));
				ResultSet rs1=ps1.executeQuery();
				if(rs1.next())
				{
					type=rs1.getString("Type");
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return type;
	}
	public static Login getLogin(int user_id)
	{
		Login login=new Login();
		boolean result=false;
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		PreparedStatement ps;
		try {
			ps=con.prepareStatement(rb.getString("FETCH_LOG_ID"));
			ps.setInt(1, user_id);
			ResultSet rs1=ps.executeQuery();
			if(rs1.next())
			{
				login=new Login(RegistrationDAO.getRegister(rs1.getInt("reg_id")),rs1.getString("user_name"),rs1.getString("password"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return login;
	}
	
	
	public static Login getLogin_by_username(String user_name)
	{
		Login login=new Login();
		boolean result=false;
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		PreparedStatement ps;
		try {
			ps=con.prepareStatement(rb.getString("FETCH_LOG_ID_BY_EMAIL"));
			ps.setString(1, user_name);
			ResultSet rs1=ps.executeQuery();
			if(rs1.next())
			{
				login=new Login(RegistrationDAO.getRegister(rs1.getInt("reg_id")),rs1.getString("user_name"),rs1.getString("password"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return login;
	}
	
	
	
}
