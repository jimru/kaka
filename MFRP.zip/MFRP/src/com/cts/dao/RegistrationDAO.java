package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.cts.util.DBConnect;
import com.cts.vo.Contract;
import com.cts.vo.Location;
import com.cts.vo.Login;
import com.cts.vo.Register;





public class RegistrationDAO {
	
	
	public static boolean registerUser(Register register)
	{
		DBConnect dconnect=new DBConnect();
		boolean result=false;
		Connection con=dconnect.getConnect();
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement ps=con.prepareStatement(rb.getString("REGISTER_USER"));
			ps.setString(1, register.getFirst_name());
			ps.setString(2, register.getLast_name());
			ps.setInt(3, register.getAge());
			ps.setString(4, register.getGender());
			ps.setString(5, register.getContact_no());
			ps.setString(6, register.getEmail());
			ps.setString(7, register.getAddress());
			ps.setString(8, register.getZip());
			ps.setString(9, register.getCity());
			ps.setString(10, register.getType());
			ps.executeUpdate();
			PreparedStatement ps0=con.prepareStatement(rb.getString("FETCH_REG_ID"));
			ps0.setString(1, register.getEmail());
			ResultSet rs=ps0.executeQuery();
			if(rs.next())
			{
			PreparedStatement ps1=con.prepareStatement(rb.getString("REGISTER_USER_LOGIN"));
			ps1.setInt(1, RegistrationDAO.getUserId(register.getEmail()).getReg_id());
			ps1.setString(2, register.getEmail());
			ps1.setString(3, register.getPassword());
			ps1.executeUpdate();
			result=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
		}
		catch(Exception e)
		{
			System.err.println("User already Exist");
		}
	return result;
		
	}
	public static Register getUserId(String name)
	{
		Register reg=null;
		DBConnect dconnect=new DBConnect();
		boolean result=false;
		Connection con=dconnect.getConnect();
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		try
		{
		PreparedStatement preparestatement=con.prepareStatement(rb.getString("FETCH_REG_DETAILS"));
		preparestatement.setString(1, name);
		ResultSet resultset=preparestatement.executeQuery();
			if(resultset.next())
			{
				reg=new Register(resultset.getInt("Reg_id"),resultset.getString("First_name"),resultset.getString("Last_name"),resultset.getInt("Age"),resultset.getString("Gender"),resultset.getString("Contact_number"),resultset.getString("Email"),resultset.getString("Address"),resultset.getString("Zip_code"),resultset.getString("City"),resultset.getString("Type"));
			} 
		
		}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				System.err.println(e);
	}
		return reg;
		
	}
	public static boolean updateAdmin(Register update)
	{
		boolean result=false;
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement ps=con.prepareStatement(rb.getString("UPDATE_USER"));
			ps.setString(1, update.getFirst_name());
			ps.setString(2, update.getLast_name());
			ps.setInt(3, update.getAge());
			ps.setString(4, update.getGender());
			ps.setString(5, update.getContact_no());
			ps.setString(6, update.getAddress());
			ps.setString(7, update.getZip());
			ps.setString(8, update.getCity());
			ps.setString(9, update.getType());
			ps.setString(10, update.getEmail());
			ps.executeUpdate();
			PreparedStatement ps1=con.prepareStatement(rb.getString("UPDATE_USER_LOGIN"));
			ps1.setString(1, update.getPassword());
			ps1.setString(2, update.getEmail());
			ps1.executeUpdate();
			result=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	
	public static String getZipcode(String city)
	{
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		Location location=null;
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparestatement1=con.prepareStatement(rb.getString("GET_ZIP_CODE"));
			preparestatement1.setString(1, city);
			ResultSet resultset=preparestatement1.executeQuery();
			if(resultset.next())
			{
				 location=new Location(city,resultset.getString("Zip_code"));
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return location.getZip_code();
		
	}
	
	public static List<Location> getCity()
	{
	
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		List<Location> list=new ArrayList<Location>();
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		try {
			PreparedStatement preparedStatement2=con.prepareStatement(rb.getString("GET_CITY"));
			ResultSet resultset1=preparedStatement2.executeQuery();
			while(resultset1.next())
			{
				Location location=new Location(resultset1.getString("City"),resultset1.getString("Zip_code"));
				list.add(location);
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public static Register getRegister(int user_id)
	{
		Register register=new Register();
		boolean result=false;
		ResourceBundle rb=ResourceBundle.getBundle("QueryConstant");
		DBConnect dbcon=new DBConnect();
		Connection con=dbcon.getConnect();
		PreparedStatement ps;
		try {
			ps=con.prepareStatement(rb.getString("FETCH_USER_NAME"));
			ps.setInt(1, user_id);
			ResultSet resultset=ps.executeQuery();
			if(resultset.next())
			{
				register=new Register(resultset.getInt("Reg_id"),resultset.getString("First_name"),resultset.getString("Last_name"),resultset.getInt("Age"),resultset.getString("Gender"),resultset.getString("Contact_number"),resultset.getString("Email"),resultset.getString("Address"),resultset.getString("Zip_code"),resultset.getString("City"),resultset.getString("Type"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return register;
	}
	
}
