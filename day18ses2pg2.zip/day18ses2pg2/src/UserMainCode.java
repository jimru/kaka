import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class UserMainCode {
	void displayAge(String str1,String str2) throws Exception
	
	{		
		LocalDate ld1=LocalDate.parse(str1,DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		LocalDate ld2=LocalDate.parse(str2,DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		
		Period p=Period.between(ld1,ld2);
		
		System.out.println("I am  "+p.getYears()+" years, "+p.getMonths()+" months and "+p.getDays()+" days old.");
		
		
	}

}

