import java.util.Scanner;


public class Main {
	public static void main(String[] args) throws Exception{
		Scanner sc=new Scanner(System.in);
		String str1=sc.nextLine();
		String str2=sc.nextLine();
		UserMainCode umc=new UserMainCode();
		umc.displayAge(str1, str2);
	}

}
