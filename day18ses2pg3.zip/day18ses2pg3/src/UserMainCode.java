import java.util.*;
import java.text.*;
public class UserMainCode {
	

	void displayDay(String str)throws Exception{
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf1=new SimpleDateFormat("EEEE");
		
		Date date1=sdf.parse(str);
		
         str=sdf.format(date1);
		
		String word[]=str.split("-");
		int word0=Integer.parseInt(word[0]);
		int word1=Integer.parseInt(word[1]);
		int word2=Integer.parseInt(word[2]);
		
		Calendar cal=new GregorianCalendar(word0, word1-1, (word2-10));
		Date date2=cal.getTime();
		str=sdf.format(date2);
		System.out.println(str);
		str=sdf1.format(date2);
		System.out.println(str);
		
		
		Calendar cal1=new GregorianCalendar(word0, word1-1, (word2+10));
		Date date3=cal1.getTime();
		str=sdf.format(date3);
		System.out.println(str);
		str=sdf1.format(date3);
		System.out.println(str);

}
}

