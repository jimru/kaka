import java.util.*;
import java.text.*;
public class UserMainCode {
	void displayDate(int year,int days) throws Exception{
		
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal=new GregorianCalendar(year,00,00);
		cal.add(Calendar.DAY_OF_MONTH, days);		
		
		System.out.println(days+"th day of "+year+" : "+sdf.format(cal.getTime()));
	}

}
