import java.util.*;
import java.text.*;
public class Main {
public static void main(String[] args)throws Exception {
	
	Scanner sc=new Scanner(System.in);
	int year=sc.nextInt();
	int days=sc.nextInt();
	
	UserMainCode umc=new UserMainCode();
	umc.displayDate(year, days);


	
	
}
}

