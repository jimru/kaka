import java.util.*;
import java.text.*;
public class UserMainCode {

	void displayDate(String str) throws Exception
	{
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date date1=sdf.parse(str);
		
		str=sdf.format(date1);
		
		String word[]=str.split("-");
		int word0=Integer.parseInt(word[0]);
		int word1=Integer.parseInt(word[1]);
		int word2=Integer.parseInt(word[2]);
		
		
		
		Calendar cal=new GregorianCalendar(word0,word1,word2);
		
		cal.add(Calendar.MONTH, -21);
		
		
		
		
		System.out.println("20 months before "+str+" will be "+sdf.format(cal.getTime()));
		
		
		
	}
}
